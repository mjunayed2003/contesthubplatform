"use client";

import React, { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, Pencil, Download, Search, Eye, Check, X,
  Users, FileText, Clock, CheckCircle2, Trophy, BarChart2,
  TrendingUp, Info,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ─── TYPES ────────────────────────────────────────────────────
type Tab = "overview" | "participants" | "submissions" | "poll" | "winner";

interface Participant {
  id: number;
  name: string;
  email: string;
  joinDate: string;
  submissions: number;
  status: "Submitted" | "Approved" | "Pending";
}

interface Submission {
  id: number;
  name: string;
  email: string;
  image: string;
  content: string;
  date: string;
  votes: number;
  status: "Approved" | "Pending" | "Rejected";
}

interface PollOption {
  label: string;
  votes: number;
  color: string;
  barColor: string;
}

// ─── MOCK DATA ─────────────────────────────────────────────────
const PARTICIPANTS: Participant[] = Array.from({ length: 9 }, (_, i) => ({
  id: i + 1,
  name: "Sarah Johnson",
  email: "sarah.j@email.com",
  joinDate: "2/5/2026",
  submissions: 2,
  status: i % 3 === 0 ? "Approved" : i % 3 === 1 ? "Pending" : "Submitted",
}));

const SUBMISSIONS: Submission[] = Array.from({ length: 7 }, (_, i) => ({
  id: i + 1,
  name: "Sarah Johnson",
  email: "sarah.j@email.com",
  image: "/images/contest2.jpg",
  content: "Beautiful sunset photograph from my recent beach trip",
  date: "2/5/2026,  10:25PM",
  votes: 42,
  status: i % 3 === 1 ? "Pending" : i % 3 === 2 ? "Rejected" : "Approved",
}));

const POLL_OPTIONS: PollOption[] = [
  { label: "Dark Mode",          votes: 245, color: "text-blue-600",   barColor: "bg-blue-500"   },
  { label: "Mobile App",         votes: 189, color: "text-green-600",  barColor: "bg-green-500"  },
  { label: "API Integration",    votes: 150, color: "text-purple-600", barColor: "bg-purple-500" },
  { label: "Advanced Analytics", votes: 120, color: "text-orange-600", barColor: "bg-orange-500" },
];
const POLL_TOTAL = POLL_OPTIONS.reduce((s, o) => s + o.votes, 0);

// ─── STATUS STYLES ─────────────────────────────────────────────
const participantStatusStyle: Record<string, string> = {
  Submitted: "bg-blue-50 text-blue-600 border border-blue-100",
  Approved:  "bg-green-50 text-green-600 border border-green-100",
  Pending:   "bg-yellow-50 text-yellow-600 border border-yellow-100",
};
const submissionStatusStyle: Record<string, string> = {
  Approved: "bg-green-50 text-green-600 border border-green-100",
  Pending:  "bg-yellow-50 text-yellow-600 border border-yellow-100",
  Rejected: "bg-red-50 text-red-500 border border-red-100",
};

// ─── MAIN PAGE ─────────────────────────────────────────────────
export default function PollContestDetailPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  const tabs: { key: Tab; label: string }[] = [
    { key: "overview",     label: "Overview"          },
    { key: "participants", label: "Participants"       },
    { key: "submissions",  label: "Submissions"        },
    { key: "poll",         label: "Poll Results"       },
    { key: "winner",       label: "Winner Management"  },
  ];

  return (
    <div className="min-h-screen bg-white p-8">
      {/* Back */}
      <button
        onClick={() => router.push("/admin/contests")}
        className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to My Contests
      </button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2 flex-wrap">
            <h1 className="text-2xl font-bold text-gray-900">Win a Free Product Bundle</h1>
            <span className="px-2.5 py-0.5 rounded text-xs font-bold border border-green-200 text-green-600 bg-green-50 uppercase tracking-wide">Active</span>
            <span className="px-2.5 py-0.5 rounded text-xs font-bold border border-purple-200 text-purple-600 bg-purple-50 uppercase tracking-wide">Giveaway</span>
          </div>
          <p className="text-gray-500 text-sm">Follow and win amazing prizes</p>
        </div>
        <button className="flex items-center gap-2 bg-[#A01C1C] hover:bg-[#851717] text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors shadow-sm shrink-0">
          <Pencil className="w-4 h-4" /> Edit Contest
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 flex-wrap">
        {tabs.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={cn(
              "px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200",
              activeTab === key
                ? "bg-[#A01C1C] text-white shadow-sm"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {activeTab === "overview"     && <OverviewTab />}
      {activeTab === "participants" && <ParticipantsTab />}
      {activeTab === "submissions"  && <SubmissionsTab />}
      {activeTab === "poll"         && <PollResultsTab />}
      {activeTab === "winner"       && <WinnerTab />}
    </div>
  );
}

/* ─── OVERVIEW TAB ─────────────────────────────────────────── */
function OverviewTab() {
  const stats = [
    { label: "Total Participants", value: "5,420", icon: Users,    iconBg: "bg-blue-50",   iconColor: "text-blue-500"   },
    { label: "Total Submissions",  value: "5,420", icon: FileText, iconBg: "bg-green-50",  iconColor: "text-green-500"  },
    { label: "Engagement Rate",    value: "78%",   icon: Clock,    iconBg: "bg-purple-50", iconColor: "text-purple-500" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {stats.map(({ label, value, icon: Icon, iconBg, iconColor }) => (
          <div key={label} className="border border-gray-100 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center`}>
                <Icon className={`w-5 h-5 ${iconColor}`} />
              </div>
              <span className="text-sm text-gray-500 font-medium">{label}</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      <div className="border border-gray-100 rounded-2xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-gray-900 mb-4">Contest Information</h3>
        <div className="space-y-3">
          <div>
            <p className="text-xs text-gray-400 font-medium mb-1">Full Description</p>
            <p className="text-sm text-gray-700">
              Help us decide which feature to build next by voting in our community poll!
            </p>
          </div>
          <div>
            <p className="text-xs text-gray-400 font-medium mb-1">Rules & Guidelines</p>
            <p className="text-sm text-gray-700">One vote per user.</p>
          </div>
        </div>
      </div>

      <div className="border border-gray-100 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-4 h-4 text-gray-500" />
          <h3 className="text-base font-bold text-gray-900">Timeline</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-gray-400 mb-1">Start Date :</p>
            <p className="text-sm font-medium text-gray-800">Thursday, February 5, 2026</p>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-1">End Date :</p>
            <p className="text-sm font-medium text-gray-800">Friday, February 20, 2026</p>
          </div>
        </div>
      </div>

      <div className="border border-gray-100 rounded-2xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-gray-900 mb-1">Poll Question</h3>
        <p className="text-sm text-gray-700 mb-4">Which feature would you like to see next?</p>
        <p className="text-xs text-gray-400 font-medium mb-2">Options</p>
        <div className="space-y-1.5">
          {POLL_OPTIONS.map((opt) => (
            <p key={opt.label} className="text-sm text-gray-700">{opt.label}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── PARTICIPANTS TAB ─────────────────────────────────────── */
function ParticipantsTab() {
  const [search, setSearch] = useState("");
  const [modalParticipant, setModalParticipant] = useState<Participant | null>(null);

  const filtered = PARTICIPANTS.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <div className="border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-6 gap-3">
          <div>
            <h3 className="text-base font-bold text-gray-900">Participants</h3>
            <p className="text-xs text-gray-400 mt-0.5">Total Number: {PARTICIPANTS.length}</p>
          </div>
          <button className="flex items-center gap-2 bg-[#A01C1C] hover:bg-[#851717] text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
        <div className="px-6 pb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search participants by name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 h-10 rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-[#A01C1C]/20 focus:border-[#A01C1C]"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-t border-b border-gray-100 bg-gray-50/50">
                {["Participant", "Email", "Join Date", "Submissions", "Status", "Actions"].map((h) => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{p.name}</td>
                  <td className="px-6 py-4 text-gray-500">{p.email}</td>
                  <td className="px-6 py-4 text-gray-500">{p.joinDate}</td>
                  <td className="px-6 py-4 text-gray-700">{p.submissions}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${participantStatusStyle[p.status]}`}>
                      {p.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setModalParticipant(p)}
                      className="text-[#A01C1C] text-xs font-semibold hover:underline"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalParticipant && (
        <ParticipantDetailModal
          participant={modalParticipant}
          onClose={() => setModalParticipant(null)}
        />
      )}
    </>
  );
}

/* ─── PARTICIPANT DETAIL MODAL ─────────────────────────────── */
function ParticipantDetailModal({ participant, onClose }: { participant: Participant; onClose: () => void }) {
  const submissionHistory = Array.from({ length: participant.submissions }, (_, i) => ({
    id: i + 1,
    image: i % 2 === 0 ? "/images/contest2.jpg" : "/images/contest3.jpg",
    content: i === 0 ? "Beautiful sunset photograph from my recent beach trip" : "Cityscape photo taken during golden hour",
    date: "2/5/2026, 10:25PM",
    status: i === 0 ? "Approved" : "Pending",
  }));

  const statusColor: Record<string, string> = {
    Approved: "bg-green-50 text-green-600 border border-green-100",
    Pending:  "bg-yellow-50 text-yellow-600 border border-yellow-100",
    Rejected: "bg-red-50 text-red-500 border border-red-100",
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-100 sticky top-0 bg-white z-10">
          <h3 className="text-base font-bold text-gray-900">Participant Details</h3>
          <button onClick={onClose} className="w-7 h-7 rounded-full flex items-center justify-center text-gray-400 hover:bg-gray-100">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6 space-y-5">
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
            <div className="w-14 h-14 rounded-full bg-[#A01C1C]/10 flex items-center justify-center shrink-0">
              <span className="text-xl font-black text-[#A01C1C]">{participant.name.charAt(0)}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-base font-bold text-gray-900 truncate">{participant.name}</p>
              <p className="text-sm text-gray-400 truncate">{participant.email}</p>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${participantStatusStyle[participant.status]}`}>
              {participant.status.toUpperCase()}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-blue-50 rounded-xl p-4 text-center border border-blue-100">
              <p className="text-2xl font-black text-blue-600">{participant.submissions}</p>
              <p className="text-[11px] text-blue-400 font-medium mt-0.5">Submissions</p>
            </div>
            <div className="bg-green-50 rounded-xl p-4 text-center border border-green-100">
              <p className="text-2xl font-black text-green-600">{submissionHistory.filter(s => s.status === "Approved").length}</p>
              <p className="text-[11px] text-green-400 font-medium mt-0.5">Approved</p>
            </div>
            <div className="bg-yellow-50 rounded-xl p-4 text-center border border-yellow-100">
              <p className="text-2xl font-black text-yellow-600">{submissionHistory.filter(s => s.status === "Pending").length}</p>
              <p className="text-[11px] text-yellow-400 font-medium mt-0.5">Pending</p>
            </div>
          </div>
          <div className="flex items-center justify-between px-4 py-3 bg-gray-50 rounded-xl border border-gray-100">
            <div className="flex items-center gap-2 text-gray-500">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">Joined Date</span>
            </div>
            <span className="text-sm font-semibold text-gray-800">{participant.joinDate}</span>
          </div>
          <div>
            <h4 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-gray-400" /> Submission History
            </h4>
            <div className="space-y-3">
              {submissionHistory.map((sub) => (
                <div key={sub.id} className="flex items-start gap-3 p-3 rounded-xl border border-gray-100 hover:bg-gray-50">
                  <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0 border border-gray-100">
                    <Image src={sub.image} alt="submission" width={48} height={48} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-600 line-clamp-2">{sub.content}</p>
                    <p className="text-[11px] text-gray-400 mt-1">{sub.date}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${statusColor[sub.status]}`}>
                    {sub.status.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="px-6 pb-6">
          <button onClick={onClose} className="w-full h-11 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── SUBMISSIONS TAB ──────────────────────────────────────── */
function SubmissionsTab() {
  const [search, setSearch]             = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [submissions, setSubmissions]   = useState<Submission[]>(SUBMISSIONS);
  const [selectedItem, setSelectedItem] = useState<Submission | null>(null);
  const [activeModal, setActiveModal]   = useState<"detail" | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  const statusFilters = ["All", "Approved", "Pending", "Rejected"];

  const filtered = submissions.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.email.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "All" || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const openDetail = (s: Submission) => {
    setSelectedItem(s);
    setRejectReason("");
    setActiveModal("detail");
  };

  const closeAll = () => {
    setActiveModal(null);
    setSelectedItem(null);
    setRejectReason("");
  };

  const handleApprove = (id: number) => {
    setSubmissions((prev) =>
      prev.map((s) => s.id === id ? { ...s, status: "Approved" as const } : s)
    );
    closeAll();
  };

  const handleRejectConfirm = () => {
    if (!selectedItem || !rejectReason.trim()) return;
    setSubmissions((prev) =>
      prev.map((s) => s.id === selectedItem.id ? { ...s, status: "Rejected" as const } : s)
    );
    closeAll();
  };

  return (
    <>
      <div className="border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-6 gap-3">
          <div>
            <h3 className="text-base font-bold text-gray-900">Submissions</h3>
            <p className="text-xs text-gray-400 mt-0.5">Total Number: {submissions.length}</p>
          </div>
          <button className="flex items-center gap-2 bg-[#A01C1C] hover:bg-[#851717] text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>

        <div className="px-6 pb-4 flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search participants by name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 h-10 rounded-xl border border-gray-200 bg-gray-50 text-sm placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-[#A01C1C]/20 focus:border-[#A01C1C]"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-10 px-3 rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-600 outline-none focus:ring-2 focus:ring-[#A01C1C]/20 focus:border-[#A01C1C]"
          >
            {statusFilters.map((f) => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-t border-b border-gray-100 bg-gray-50/50">
                {["User", "Preview", "Submission Date", "Status", "Votes", "Actions"].map((h) => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <p className="font-medium text-gray-900">{s.name}</p>
                    <p className="text-xs text-gray-400">{s.email}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 border border-gray-100">
                        <Image src={s.image} alt="submission" width={40} height={40} className="w-full h-full object-cover" />
                      </div>
                      <span className="text-xs text-gray-600 line-clamp-2 max-w-[180px]">{s.content}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-500 text-xs">{s.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${submissionStatusStyle[s.status]}`}>
                      {s.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-700 font-semibold">{s.votes}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openDetail(s)}
                        className="w-7 h-7 rounded-full flex items-center justify-center text-blue-500 hover:bg-blue-50"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {/* Quick Approve/Reject — Pending  */}
                      {s.status === "Pending" && (
                        <>
                          <button
                            onClick={() => handleApprove(s.id)}
                            className="w-7 h-7 rounded-full flex items-center justify-center text-green-500 hover:bg-green-50"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => openDetail(s)}
                            className="w-7 h-7 rounded-full flex items-center justify-center text-red-500 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Detail Modal with inline Reject Reason ── */}
      {activeModal === "detail" && selectedItem && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={closeAll}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-gray-100 sticky top-0 bg-white z-10">
              <h3 className="text-base font-bold text-gray-900">Submission Details</h3>
              <button
                onClick={closeAll}
                className="w-7 h-7 rounded-full flex items-center justify-center text-gray-400 hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Image */}
              <div className="w-full h-52 rounded-xl overflow-hidden">
                <Image
                  src={selectedItem.image}
                  alt="submission"
                  width={500}
                  height={220}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Info */}
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Submitted by</p>
                  <p className="text-sm font-semibold text-gray-900">{selectedItem.name}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Content</p>
                  <p className="text-sm text-gray-700">{selectedItem.content}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Submission Date</p>
                  <p className="text-sm text-gray-700">{selectedItem.date}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-0.5">Total Votes</p>
                  <p className="text-sm font-bold text-gray-900">{selectedItem.votes}</p>
                </div>
              </div>

              {/* ── Reject Reason — all time visible ── */}
              <div className="border border-gray-100 rounded-xl p-4 bg-gray-50/70 space-y-3">
                <p className="text-xs text-gray-500 font-medium">
                  Rejection reason{" "}
                  <span className="text-gray-400">(required to reject)</span>
                </p>

                {/* Quick presets */}
                <div className="flex flex-wrap gap-2">
                  {[
                    "Does not meet guidelines",
                    "Low image quality",
                    "Off-topic content",
                    "Duplicate submission",
                  ].map((p) => (
                    <button
                      key={p}
                      onClick={() => setRejectReason(rejectReason === p ? "" : p)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg border text-xs font-medium transition-all",
                        rejectReason === p
                          ? "bg-[#A01C1C] border-[#A01C1C] text-white"
                          : "border-gray-200 bg-white text-gray-600 hover:border-[#A01C1C] hover:text-[#A01C1C]"
                      )}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                {/* Textarea */}
                <textarea
                  rows={3}
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value.slice(0, 300))}
                  placeholder="Or write a custom reason for rejection..."
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-[#A01C1C]/20 focus:border-[#A01C1C] resize-none transition"
                />
                <p className="text-[11px] text-gray-400 text-right -mt-1">
                  {rejectReason.length}/300
                </p>
              </div>
            </div>

            {/* Buttons  */}
            <div className="grid grid-cols-2 gap-3 px-6 pb-6">
              <button
                disabled={!!rejectReason.trim()}
                onClick={() => handleApprove(selectedItem.id)}
                className="flex items-center justify-center gap-2 h-11 rounded-xl bg-green-500 hover:bg-green-600 disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold text-sm transition-colors"
              >
                <Check className="w-4 h-4" /> Approve
              </button>

              <button
                disabled={!rejectReason.trim()}
                onClick={handleRejectConfirm}
                className="flex items-center justify-center gap-2 h-11 rounded-xl bg-[#A01C1C] hover:bg-[#851717] disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold text-sm transition-colors"
              >
                <X className="w-4 h-4" /> Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ─── POLL RESULTS TAB ─────────────────────────────────────── */
function PollResultsTab() {
  const leadingOption = POLL_OPTIONS.reduce((a, b) => a.votes > b.votes ? a : b);
  const leadingPct = Math.round((leadingOption.votes / POLL_TOTAL) * 100);

  const pollStats = [
    { label: "Total Votes",           value: "83",  icon: TrendingUp, iconBg: "bg-blue-50",   iconColor: "text-blue-500"   },
    { label: "Options",               value: "04",  icon: Trophy,     iconBg: "bg-green-50",  iconColor: "text-green-500"  },
    { label: "Avg. Votes Per Option", value: "132", icon: BarChart2,  iconBg: "bg-purple-50", iconColor: "text-purple-500" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-base font-bold text-gray-900">Poll Results</h3>
          <p className="text-xs text-gray-400 mt-0.5">Total votes: 744</p>
        </div>
        <button className="flex items-center gap-2 bg-[#A01C1C] hover:bg-[#851717] text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm">
          <Download className="w-4 h-4" /> Export Results
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {pollStats.map(({ label, value, icon: Icon, iconBg, iconColor }) => (
          <div key={label} className="border border-gray-100 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center`}>
                <Icon className={`w-5 h-5 ${iconColor}`} />
              </div>
              <span className="text-sm text-gray-500 font-medium">{label}</span>
            </div>
            <p className="text-3xl font-bold text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      <div className="border border-gray-100 rounded-2xl p-6 shadow-sm space-y-5">
        <div>
          <h3 className="text-base font-bold text-gray-900">Which feature would you like to see next?</h3>
          <p className="text-xs text-gray-400 mt-0.5">Results based on 732 votes</p>
        </div>

        <div className="space-y-5">
          {POLL_OPTIONS.map((opt) => {
            const pct = Math.round((opt.votes / POLL_TOTAL) * 100);
            return (
              <div key={opt.label}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-sm font-medium text-gray-800">{opt.label}</span>
                  <span className="text-sm text-gray-500">
                    <span className="font-semibold text-gray-800">{opt.votes} Votes</span>
                    <span className="text-xs text-gray-400 ml-2">{pct}% of total votes</span>
                  </span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${opt.barColor} transition-all duration-700`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-3 bg-green-50 border border-green-100 rounded-xl px-4 py-3">
          <Trophy className="w-4 h-4 text-green-500 shrink-0" />
          <div>
            <span className="text-xs font-bold text-green-700">Leading Option </span>
            <span className="text-xs text-green-600">
              "{leadingOption.label}" with {leadingOption.votes} votes ({leadingPct}%)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── WINNER MANAGEMENT TAB ────────────────────────────────── */
function WinnerTab() {
  const [published, setPublished]     = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const leadingOption = POLL_OPTIONS.reduce((a, b) => a.votes > b.votes ? a : b);

  return (
    <>
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-base font-bold text-gray-900">Winner Management</h3>
            <p className="text-xs text-gray-400 mt-0.5">View and publish poll results</p>
          </div>
          <button className="flex items-center gap-2 bg-[#A01C1C] hover:bg-[#851717] text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <Download className="w-4 h-4" /> Export Results
          </button>
        </div>

        <div className="border border-gray-100 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-xl px-4 py-3">
            <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-blue-800">Poll Results</p>
              <p className="text-xs text-blue-600 mt-0.5">
                Review the poll results and publish them when ready. The leading option will be highlighted.
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-base font-bold text-gray-900 mb-4">Which feature would you like to see next?</h3>
            <div className="space-y-4">
              {POLL_OPTIONS.map((opt) => {
                const pct = Math.round((opt.votes / POLL_TOTAL) * 100);
                const isLeading = opt.label === leadingOption.label;
                return (
                  <div
                    key={opt.label}
                    className={cn(
                      "rounded-xl p-4",
                      isLeading ? "bg-green-50 border border-green-100" : ""
                    )}
                  >
                    <div className="flex justify-between items-center mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-gray-800">{opt.label}</span>
                        {isLeading && <Trophy className="w-4 h-4 text-green-500" />}
                      </div>
                      <span className="text-sm text-gray-500">
                        <span className="font-semibold text-gray-800">{opt.votes} Votes</span>
                        <span className="text-xs text-gray-400 ml-2">{pct}% of total votes</span>
                      </span>
                    </div>
                    <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${opt.barColor} transition-all duration-700`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {published && (
            <div className="flex items-start gap-3 bg-green-50 border border-green-200 rounded-xl p-4">
              <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-bold text-green-700">Results Published</p>
                <p className="text-xs text-green-600 mt-0.5">
                  The contest results have been published and winners have been notified.
                </p>
              </div>
            </div>
          )}

          {!published && (
            <button
              onClick={() => setShowConfirm(true)}
              className="w-full flex items-center justify-center gap-2 h-12 rounded-xl bg-green-500 hover:bg-green-600 text-white font-semibold text-sm shadow-sm transition-colors"
            >
              <Trophy className="w-4 h-4" /> Confirm Winner & Publish Results
            </button>
          )}
        </div>
      </div>

      {/* Confirm Modal */}
      {showConfirm && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setShowConfirm(false)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-green-500" />
              </div>
              <h3 className="text-base font-bold text-gray-900">Confirm & Publish Results</h3>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Are you sure you want to publish the results? This action will:
            </p>
            <ul className="space-y-1.5 mb-6">
              {[
                "Mark the contest as completed",
                "Notify all winners via email",
                "Make results visible to all participants",
                "This action cannot be undone",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2 text-sm text-gray-600">
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-400 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="h-11 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => { setPublished(true); setShowConfirm(false); }}
                className="h-11 rounded-xl bg-green-500 hover:bg-green-600 text-white text-sm font-semibold"
              >
                Confirm & Publish
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}